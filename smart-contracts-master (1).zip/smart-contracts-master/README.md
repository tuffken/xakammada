This repository contains kyber network swap smart contracts.
For instructions on how to integrate your wallet with us, please go [here](https://github.com/KyberNetwork/smart-contracts/blob/master/integration.md).

For more details please visit our [developer portal](https://developer.kyber.network/)
